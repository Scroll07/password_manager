from pas_app.cli.app import app


def main():
    app()


if __name__=='__main__':
    main()